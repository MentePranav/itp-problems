#include <stdio.h>

int is_symmetric(char strip[], int end)
{
    int value = end;
    int flag = 1;
    for(int i = 0; i< value/2; i++){
        if(strip[i] != strip[end-i-1]){
            flag = 0;
        }
    }
    
    if(flag){
        return 1;
    }
    
    return 0;
}

int main(void)
{
    char strip[101];

    scanf("%s", strip);
    int length = 0;
    for( int i =0; strip[i] != '\0'; i++){
        length++;
    }
    
    int count;
  for(int i=0; i<length; i++){
      if(is_symmetric(strip,i)==1){
          count = i;
      }
  }
  
    printf("%d\n", count);
    for( int i=0; i< count; i++){
        printf("%c" , strip[i]);
    }
 
   
    return 0;
}