#include <stdio.h>
#include <string.h>
#include <stdbool.h>

bool is_symmetric(char strip[], int end)
{
    /* Check whether the prefix from position 0 to end is symmetric. */
    /* Return 1 or 0. Avoid performing input/output. here */

    for(int i=0; i<(end)+1; i++){
        if(strip[i] == strip[end-i] && ((end - i)>0)){
            return true;
        }
        else{
            return false;
        }
    }
    return 1;
}

int main(void)
{
    char strip[101];
    int length = 0;
    int end;
    char newstrip[101];

    /* Read the string and find its length without using string.h. */
    scanf("%s", &strip[101]);
    
    for(int i=0; i<10; i++){
        if(strip[i] != '\0'){
            length++;
        }
        else{
            break;
        }
    }
    
    
    
    
    for(int i=1; i<length; i++){
        if(strip[length - i] == strip[0]){
            end = strip[i];
            break;
        }
        else{
            end = 1;
        }
    }
    
    /* Perform necessary computations using the function */

    for(int i=0; i<length; i++){
        newstrip[i] = strip[i];
    }
    
    if(is_symmetric(strip, end)){
        printf("%d\n", end+1);
        printf("%s", newstrip);
    }
    
    
    /* Print length output, then print the symmetric prefix on the next line. */

    return 0;
}