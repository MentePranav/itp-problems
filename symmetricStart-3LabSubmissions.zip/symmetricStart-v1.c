#include <stdio.h>

int is_symmetric(char strip[], int n)
{ int x = 0;
    char c;
     for (int i =1 ; i < n; i++){
        if (strip[0] == strip[i]){
          
            for(int j = 1; j < n; j++){
                if (strip[j] =! strip[i-j]){
                    return 0;
                }else {
                    return i;
                }
            }
        }
     }
    /* Check whether the prefix from position 0 to end is symmetric. */
    /* Return 1 or 0. Avoid performing input/output. here */
}

int main(void)
{
    char strip[101];
    int n = 0;
    int a;

    /* Read the string and find its length without using string.h. */
    for (int j = 0; j < 10; j++){
    scanf("%s",&strip[j]);
    }
for (int i =0 ; i < 10; i++){
        //printf("%c\n",strip[i]);
        n = n + 1;
            
       if (strip[i] == '\0'){
           break;
       }
    }  
    n = n - 1;
 //printf("%d\n",n);
    /* Perform necessary computations using the function */
    a = is_symmetric(strip,n);
    printf("%d\n",a);
    for (int i = 0; i <= a ; i++ ){
    printf("%c",strip[i]);}
    /* Print length output, then print the symmetric prefix on the next line. */

    return 0;
}